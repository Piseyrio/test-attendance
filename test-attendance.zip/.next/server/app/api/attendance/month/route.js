var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/attendance/month/route.js")
R.c("server/chunks/[root-of-the-server]__24268a1b._.js")
R.c("server/chunks/node_modules_next_280e602b._.js")
R.m("[project]/.next-internal/server/app/api/attendance/month/route/actions.js [app-rsc] (server actions loader, ecmascript)")
R.m("[project]/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/src/app/api/attendance/month/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)")
module.exports=R.m("[project]/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/src/app/api/attendance/month/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)").exports
