(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_560d2263._.js",
  "static/chunks/src_components_ui_sonner_tsx_c1caca9b._.js"
],
    source: "dynamic"
});
