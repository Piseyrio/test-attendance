(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_c33a8b42._.js",
  "static/chunks/node_modules_tailwind-merge_dist_bundle-mjs_mjs_56b6fd65._.js",
  "static/chunks/node_modules_@tanstack_table-core_build_lib_index_mjs_b0999871._.js",
  "static/chunks/node_modules_zod_v4_74759941._.js",
  "static/chunks/node_modules_8f85837c._.js"
],
    source: "dynamic"
});
