
export default function Attendance() {
    return(
        <div className="p-4">
            <h1 className="mb-4 text-2xl font-bold">Attendance Page</h1>
        </div>
    )
};
